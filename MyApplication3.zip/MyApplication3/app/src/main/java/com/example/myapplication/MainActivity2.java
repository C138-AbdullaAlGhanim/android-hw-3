package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        final TextView name = findViewById(R.id.name);
        final TextView age = findViewById(R.id.age);
        final TextView job = findViewById(R.id.job);
        final TextView phone = findViewById(R.id.phone);
        final TextView email = findViewById(R.id.email);

        Bundle l = getIntent().getExtras();
        String r = l.getString("info");
        String p = l.getString("infor");
        String o = l.getString("inform");
        String t = l.getString("informa");
        String v = l.getString("informat");

        name.setText(r);
        age.setText(p);
        job.setText(o);
        phone.setText(t);
        email.setText(v);

    }
}