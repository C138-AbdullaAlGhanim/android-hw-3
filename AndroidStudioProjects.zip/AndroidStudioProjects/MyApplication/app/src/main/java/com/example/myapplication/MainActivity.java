package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editTextTextPersonName);
        final EditText y = findViewById(R.id.editTextTextPersonName2);
        final EditText a = findViewById(R.id.editTextTextPersonName3);
        final EditText b = findViewById(R.id.editTextTextPersonName4);
        final TextView z = findViewById(R.id.textView2);
        Button add = findViewById(R.id.button);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int g = Integer.parseInt(x.getText().toString());
                int k = Integer.parseInt(y.getText().toString());
                int c = Integer.parseInt(a.getText().toString());
                int d = Integer.parseInt(b.getText().toString());
                int Abdulla = g + k + c + d;
                z.setText(Abdulla + "");
            }
        });


    }
}
