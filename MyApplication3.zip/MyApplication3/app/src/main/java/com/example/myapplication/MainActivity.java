package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button a = findViewById(R.id.Button);
        final EditText n = findViewById(R.id.name);
        final EditText s = findViewById(R.id.age);
        final EditText f = findViewById(R.id.job);
        final EditText g = findViewById(R.id.phone);
        final EditText k = findViewById(R.id.email);

        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = n.getText().toString();
                String age = s.getText().toString();
                String job = f.getText().toString();
                String phone = g.getText().toString();
                String email = k.getText().toString();
                Intent x = new Intent(MainActivity.this, MainActivity2.class);
                x.putExtra("info", name);
                x.putExtra("infor", age);
                x.putExtra("inform", job);
                x.putExtra("informa", phone);
                x.putExtra("informat", email);
                startActivity(x);
            }
        });

    }
}